<?php

return [
    Symfony\Bundle\MonologBundle\MonologBundle::class => ['all' => true],
];
