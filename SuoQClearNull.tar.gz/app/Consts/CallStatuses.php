<?php

namespace App\Consts;

class CallStatuses
{
    const SERVED= 1;
    const NOSHOW = 2;
}