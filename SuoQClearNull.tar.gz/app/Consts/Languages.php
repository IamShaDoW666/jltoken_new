<?php

namespace App\Consts;

class Languages
{
    const ENGLISH= 1;
    const FRENCH = 2;
    const HINDI = 3;
    const ARABIC = 4;
    const SPANISH = 5;
    const PORTUGUESE = 6;
    const ITALIAN = 7;
    const INDONESIAN = 8;
}